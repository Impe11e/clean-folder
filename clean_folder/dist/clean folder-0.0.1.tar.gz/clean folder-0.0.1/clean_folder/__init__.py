from clean_folder.main import main

__all__ = ['main']